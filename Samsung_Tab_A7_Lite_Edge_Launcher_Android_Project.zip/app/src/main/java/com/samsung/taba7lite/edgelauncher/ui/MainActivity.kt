package com.samsung.taba7lite.edgelauncher.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import com.samsung.taba7lite.edgelauncher.R
import com.samsung.taba7lite.edgelauncher.service.EdgeOverlayService

class MainActivity : AppCompatActivity() {

    private lateinit var btnGrantOverlay: Button
    private lateinit var btnWhitelistBattery: Button
    private lateinit var switchService: SwitchCompat
    private lateinit var tvOverlayStatus: TextView
    private lateinit var tvBatteryStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnGrantOverlay = findViewById(R.id.btn_grant_overlay)
        btnWhitelistBattery = findViewById(R.id.btn_whitelist_battery)
        switchService = findViewById(R.id.switch_service)
        tvOverlayStatus = findViewById(R.id.tv_overlay_status)
        tvBatteryStatus = findViewById(R.id.tv_battery_status)

        setupListeners()
    }

    override fun onResume() {
        super.onResume()
        updatePermissionStatus()
    }

    private fun setupListeners() {
        btnGrantOverlay.setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            } else {
                Toast.makeText(this, "Overlay permission already granted", Toast.LENGTH_SHORT).show()
            }
        }

        btnWhitelistBattery.setOnClickListener {
            val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !powerManager.isIgnoringBatteryOptimizations(packageName)) {
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = Uri.parse("package:$packageName")
                }
                startActivity(intent)
            } else {
                Toast.makeText(this, "Battery optimization already ignored", Toast.LENGTH_SHORT).show()
            }
        }

        switchService.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                    Toast.makeText(this, "कृपया पहले 'Appear on top' (Overlay) अनुमति दें!", Toast.LENGTH_LONG).show()
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                    startActivity(intent)
                    switchService.isChecked = false
                    return@setOnCheckedChangeListener
                }
                startOverlayService()
            } else {
                stopOverlayService()
            }
        }
    }

    private fun updatePermissionStatus() {
        val hasOverlay = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else {
            true
        }
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        val isBatteryIgnored = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            powerManager.isIgnoringBatteryOptimizations(packageName)
        } else {
            true
        }

        tvOverlayStatus.text = if (hasOverlay) "Granted (अनुमति मिल गई)" else "Required (अनुमति दें)"
        tvBatteryStatus.text = if (isBatteryIgnored) "Whitelisted (सुरक्षित)" else "Optimization active (अनुरोध करें)"

        btnGrantOverlay.isEnabled = !hasOverlay
        btnWhitelistBattery.isEnabled = !isBatteryIgnored
    }

    private fun startOverlayService() {
        try {
            val serviceIntent = Intent(this, EdgeOverlayService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
            Toast.makeText(this, "Edge Sidebar चालू हो गया!", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            android.util.Log.e("MainActivity", "Failed to start overlay service", e)
            Toast.makeText(this, "Error starting service: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun stopOverlayService() {
        try {
            val serviceIntent = Intent(this, EdgeOverlayService::class.java)
            stopService(serviceIntent)
            Toast.makeText(this, "Edge Sidebar बंद हो गया", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            // ignore
        }
    }
}
