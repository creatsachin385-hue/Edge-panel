# Proguard rules
-dontwarn **
