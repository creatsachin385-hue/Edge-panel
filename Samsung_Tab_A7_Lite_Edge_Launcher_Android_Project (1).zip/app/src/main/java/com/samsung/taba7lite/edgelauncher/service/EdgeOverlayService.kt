package com.samsung.taba7lite.edgelauncher.service

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.graphics.Point
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import androidx.core.app.NotificationCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import com.samsung.taba7lite.edgelauncher.R
import com.samsung.taba7lite.edgelauncher.data.AppInfo
import com.samsung.taba7lite.edgelauncher.data.AppRepository
import com.samsung.taba7lite.edgelauncher.ui.MainActivity
import com.samsung.taba7lite.edgelauncher.ui.QuickDrawerViewController
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlin.math.abs

/**
 * EdgeOverlayService
 * 
 * Specialized for Samsung Galaxy Tab A7 Lite (8.7" WXGA+ 1340x800):
 * - WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
 * - 0 continuous CPU wake-locks: handler/coroutine sleeps when idle
 * - 3-second auto-dimming into an 80% translucent thin vertical line
 * - Smooth hardware-accelerated drawer sliding without GPU stalls
 */
class EdgeOverlayService : LifecycleService() {

    private lateinit var windowManager: WindowManager
    private lateinit var vibrator: Vibrator
    private val mainHandler = Handler(Looper.getMainLooper())
    private var velocityTracker: VelocityTracker? = null

    // Overlay Views
    private var handleRootView: View? = null
    private var drawerRootView: View? = null
    private var drawerController: QuickDrawerViewController? = null

    // Layout Params
    private lateinit var handleParams: WindowManager.LayoutParams
    private lateinit var drawerParams: WindowManager.LayoutParams

    // State Variables
    private var isDrawerExpanded = false
    private var isHandleAtRight = true
    private var screenWidth = 1340
    private var screenHeight = 800
    private var touchSlop = 16

    // Inactivity Idle Dimming
    private val idleDimRunnable = Runnable {
        transitionHandleToIdle(true)
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        vibrator = try {
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        } catch (e: Exception) {
            null
        }
        touchSlop = ViewConfiguration.get(this).scaledTouchSlop

        // Check overlay permission to avoid BadTokenException crash
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !android.provider.Settings.canDrawOverlays(this)) {
            android.util.Log.e("EdgeOverlayService", "Overlay permission not granted. Stopping.")
            stopSelf()
            return
        }

        startForegroundServiceNotification()
        measureDisplayDimensions()
        initHandleOverlay()
        initDrawerOverlay()
        observeAppRepository()

        // Schedule first idle state
        resetInactivityTimer()
    }

    private fun startForegroundServiceNotification() {
        val channelId = "edge_launcher_service"
        val channelName = "Edge Launcher Service"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                channelName,
                NotificationManager.IMPORTANCE_MIN
            ).apply {
                description = "Keeps overlay handle active with zero battery impact"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        val openIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("Edge Quick Drawer Active")
            .setContentText("Swipe handle to launch apps")
            .setSmallIcon(R.drawable.ic_edge_handle)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setOngoing(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .build()

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) { // Android 14
                    startForeground(
                        1001,
                        notification,
                        android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                    )
                } else {
                    startForeground(1001, notification)
                }
            } else {
                startForeground(1001, notification)
            }
        } catch (e: Exception) {
            android.util.Log.e("EdgeOverlayService", "startForeground error", e)
        }
    }

    private fun measureDisplayDimensions() {
        val size = Point()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealSize(size)
        screenWidth = size.x
        screenHeight = size.y
    }

    /**
     * Initializes the floating Edge Handle view
     */
    @SuppressLint("InflateParams", "ClickableViewAccessibility")
    private fun initHandleOverlay() {
        // Critical: Must wrap Service in Theme to prevent InflateException
        val themedContext = androidx.appcompat.view.ContextThemeWrapper(this, R.style.Theme_AppLauncher)
        val inflater = LayoutInflater.from(themedContext)
        handleRootView = inflater.inflate(R.layout.overlay_edge_handle, null)

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        handleParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or if (isHandleAtRight) Gravity.END else Gravity.START
            x = 0
            y = screenHeight / 3 // Initial thumb reachability zone for Tab A7 Lite
        }

        setupHandleTouchListener()
        try {
            windowManager.addView(handleRootView, handleParams)
        } catch (e: Exception) {
            android.util.Log.e("EdgeOverlayService", "Failed to add handle overlay", e)
        }
    }

    /**
     * Draggable & Swipe-Inward Mechanics
     */
    @SuppressLint("ClickableViewAccessibility")
    private fun setupHandleTouchListener() {
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var isDraggingVertical = false

        handleRootView?.setOnTouchListener { view, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    velocityTracker = VelocityTracker.obtain()
                    velocityTracker?.addMovement(event)

                    initialY = handleParams.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isDraggingVertical = false

                    // Wake handle from idle 80% opacity immediately
                    transitionHandleToIdle(false)
                    cancelInactivityTimer()
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    velocityTracker?.addMovement(event)
                    val deltaX = event.rawX - initialTouchX
                    val deltaY = event.rawY - initialTouchY

                    if (!isDraggingVertical && abs(deltaY) > touchSlop && abs(deltaY) > abs(deltaX)) {
                        isDraggingVertical = true
                    }

                    if (isDraggingVertical) {
                        // Vertical dragging along edge to adjust reachability height
                        val newY = (initialY + deltaY).toInt()
                        handleParams.y = newY.coerceIn(60, screenHeight - 160)
                        windowManager.updateViewLayout(handleRootView, handleParams)
                    } else {
                        // Swipe inward trigger check
                        val inwardSwipe = if (isHandleAtRight) deltaX < -touchSlop * 2 else deltaX > touchSlop * 2
                        if (inwardSwipe && !isDrawerExpanded) {
                            triggerHapticFeedback()
                            expandDrawer()
                        }
                    }
                    true
                }

                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    velocityTracker?.addMovement(event)
                    velocityTracker?.computeCurrentVelocity(1000)
                    val xVelocity = velocityTracker?.xVelocity ?: 0f
                    velocityTracker?.recycle()
                    velocityTracker = null

                    val totalDeltaX = abs(event.rawX - initialTouchX)
                    val totalDeltaY = abs(event.rawY - initialTouchY)

                    if (!isDraggingVertical && totalDeltaX < touchSlop && totalDeltaY < touchSlop) {
                        // Click / Tap on handle expands drawer
                        if (!isDrawerExpanded) {
                            triggerHapticFeedback()
                            expandDrawer()
                        }
                    } else if (!isDraggingVertical) {
                        val fastInward = if (isHandleAtRight) xVelocity < -800 else xVelocity > 800
                        if (fastInward && !isDrawerExpanded) {
                            triggerHapticFeedback()
                            expandDrawer()
                        }
                    }

                    resetInactivityTimer()
                    true
                }

                else -> false
            }
        }
    }

    /**
     * Initializes the Sliding Drawer overlay
     */
    @SuppressLint("InflateParams")
    private fun initDrawerOverlay() {
        val themedContext = androidx.appcompat.view.ContextThemeWrapper(this, R.style.Theme_AppLauncher)
        val inflater = LayoutInflater.from(themedContext)
        drawerRootView = inflater.inflate(R.layout.overlay_sidebar_drawer, null)

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        // On Samsung Galaxy Tab A7 Lite (800x1340 portrait or 1340x800 landscape):
        val drawerWidth = resources.getDimensionPixelSize(R.dimen.edge_drawer_width)

        drawerParams = WindowManager.LayoutParams(
            drawerWidth,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or if (isHandleAtRight) Gravity.END else Gravity.START
            x = -drawerWidth // Hidden off-screen initially
            y = 0
        }

        drawerController = QuickDrawerViewController(
            context = themedContext,
            rootView = drawerRootView!!,
            onAppClicked = { app, launchMode ->
                handleAppLaunch(app, launchMode)
            },
            onCloseRequested = {
                collapseDrawer()
            }
        )
    }

    /**
     * Smooth hardware-accelerated drawer expand
     */
    fun expandDrawer() {
        if (isDrawerExpanded) return
        isDrawerExpanded = true
        cancelInactivityTimer()

        val drawerWidth = drawerParams.width
        if (drawerRootView?.parent == null) {
            drawerParams.x = -drawerWidth
            try {
                windowManager.addView(drawerRootView, drawerParams)
            } catch (e: Exception) {
                android.util.Log.e("EdgeOverlayService", "Failed to add drawer overlay", e)
            }
        }

        // Hide edge handle while drawer is open
        handleRootView?.visibility = View.GONE

        // ValueAnimator smoothly brings drawer into view
        ValueAnimator.ofInt(-drawerWidth, 0).apply {
            duration = 180 // Low-latency curve
            interpolator = DecelerateInterpolator()
            addUpdateListener { anim ->
                drawerParams.x = anim.animatedValue as Int
                if (drawerRootView?.parent != null) {
                    try {
                        windowManager.updateViewLayout(drawerRootView, drawerParams)
                    } catch (e: Exception) {
                        // ignore during animation
                    }
                }
            }
            start()
        }

        drawerController?.onDrawerExpanded()
    }

    /**
     * Smooth collapse animation
     */
    fun collapseDrawer() {
        if (!isDrawerExpanded) return
        val drawerWidth = drawerParams.width

        ValueAnimator.ofInt(0, -drawerWidth).apply {
            duration = 160
            interpolator = DecelerateInterpolator()
            addUpdateListener { anim ->
                drawerParams.x = anim.animatedValue as Int
                if (drawerRootView?.parent != null) {
                    try {
                        windowManager.updateViewLayout(drawerRootView, drawerParams)
                    } catch (e: Exception) {
                        // ignore during animation
                    }
                }
            }
            addOnEndListener {
                if (drawerRootView?.parent != null) {
                    try {
                        windowManager.removeView(drawerRootView)
                    } catch (e: Exception) {
                        // ignore
                    }
                }
                isDrawerExpanded = false
                handleRootView?.visibility = View.VISIBLE
                resetInactivityTimer()
            }
            start()
        }
    }

    private fun handleAppLaunch(app: AppInfo, launchMode: AppLaunchMode) {
        AppRepository.getInstance(this).launchApp(app, launchMode)
        collapseDrawer()
    }

    /**
     * Inactivity Timer: 3 seconds before handle shrinks/dims to 80% translucent
     */
    private fun resetInactivityTimer() {
        cancelInactivityTimer()
        mainHandler.postDelayed(idleDimRunnable, 3000L)
    }

    private fun cancelInactivityTimer() {
        mainHandler.removeCallbacks(idleDimRunnable)
    }

    private fun transitionHandleToIdle(idle: Boolean) {
        handleRootView?.animate()
            ?.alpha(if (idle) 0.20f else 1.0f)
            ?.scaleX(if (idle) 0.65f else 1.0f)
            ?.setDuration(220)
            ?.start()
    }

    private fun triggerHapticFeedback() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(12, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(12)
            }
        } catch (e: Exception) {
            // Ignored on tablets without vibration motor
        }
    }

    private fun observeAppRepository() {
        lifecycleScope.launch {
            AppRepository.getInstance(this@EdgeOverlayService).installedAppsFlow
                .collectLatest { apps ->
                    drawerController?.submitAppList(apps)
                }
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        measureDisplayDimensions()
        // Reposition handle within safe display bounds
        handleParams.y = handleParams.y.coerceIn(60, screenHeight - 160)
        if (handleRootView?.parent != null) {
            windowManager.updateViewLayout(handleRootView, handleParams)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        cancelInactivityTimer()
        if (handleRootView?.parent != null) {
            windowManager.removeView(handleRootView)
        }
        if (drawerRootView?.parent != null) {
            windowManager.removeView(drawerRootView)
        }
    }
}

inline fun ValueAnimator.addOnEndListener(crossinline onEnd: () -> Unit) {
    this.addListener(object : android.animation.AnimatorListenerAdapter() {
        override fun onAnimationEnd(animation: android.animation.Animator) {
            onEnd()
        }
    })
}
