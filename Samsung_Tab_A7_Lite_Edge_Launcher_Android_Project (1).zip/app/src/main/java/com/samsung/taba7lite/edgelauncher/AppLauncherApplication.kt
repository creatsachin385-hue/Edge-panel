package com.samsung.taba7lite.edgelauncher

import android.app.Application

class AppLauncherApplication : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}
