package com.samsung.taba7lite.edgelauncher.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import com.samsung.taba7lite.edgelauncher.data.AppRepository
import com.samsung.taba7lite.edgelauncher.service.EdgeOverlayService

/**
 * PackageChangeReceiver
 * 
 * Eliminates background polling! Wakes up only when apps are installed,
 * uninstalled, or updated.
 */
class PackageChangeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_PACKAGE_ADDED,
            Intent.ACTION_PACKAGE_REMOVED,
            Intent.ACTION_PACKAGE_REPLACED -> {
                // Refresh AppRepository cache dynamically
                AppRepository.getInstance(context).reloadInstalledApps()
            }

            Intent.ACTION_BOOT_COMPLETED -> {
                // Restart EdgeOverlayService after tablet reboot
                val serviceIntent = Intent(context, EdgeOverlayService::class.java)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(serviceIntent)
                } else {
                    context.startService(serviceIntent)
                }
            }
        }
    }
}
