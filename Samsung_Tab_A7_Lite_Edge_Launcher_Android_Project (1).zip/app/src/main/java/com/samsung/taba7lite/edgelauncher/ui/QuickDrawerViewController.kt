package com.samsung.taba7lite.edgelauncher.ui

import android.content.Context
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.samsung.taba7lite.edgelauncher.R
import com.samsung.taba7lite.edgelauncher.data.AppInfo
import com.samsung.taba7lite.edgelauncher.data.AppRepository
import com.samsung.taba7lite.edgelauncher.service.AppLaunchMode
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class QuickDrawerViewController(
    private val context: Context,
    private val rootView: View,
    private val onAppClicked: (AppInfo, AppLaunchMode) -> Unit,
    private val onCloseRequested: () -> Unit
) {
    private val etSearch: EditText = rootView.findViewById(R.id.et_app_search)
    private val btnClose: ImageButton = rootView.findViewById(R.id.btn_close_drawer)
    private val rvFavorites: RecyclerView = rootView.findViewById(R.id.rv_favorites)
    private val rvAllApps: RecyclerView = rootView.findViewById(R.id.rv_all_apps)

    private val allAppsAdapter = AppAdapter(context, onAppClicked)
    private val favAdapter = AppAdapter(context, onAppClicked)
    private var allApps: List<AppInfo> = emptyList()

    init {
        btnClose.setOnClickListener { onCloseRequested() }

        rvFavorites.layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
        rvFavorites.adapter = favAdapter

        rvAllApps.layoutManager = GridLayoutManager(context, 4)
        rvAllApps.adapter = allAppsAdapter

        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                filter(s?.toString().orEmpty())
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    fun submitAppList(apps: List<AppInfo>) {
        allApps = apps
        favAdapter.submitList(apps.filter { it.isFavorite })
        allAppsAdapter.submitList(apps)
    }

    fun onDrawerExpanded() {
        etSearch.text.clear()
        allAppsAdapter.submitList(allApps)
    }

    private fun filter(query: String) {
        val filtered = AppRepository.getInstance(context).filterApps(query)
        allAppsAdapter.submitList(filtered)
    }

    class AppAdapter(
        private val context: Context,
        private val onClick: (AppInfo, AppLaunchMode) -> Unit
    ) : RecyclerView.Adapter<AppAdapter.ViewHolder>() {

        private var list: List<AppInfo> = emptyList()

        fun submitList(newList: List<AppInfo>) {
            list = newList
            notifyDataSetChanged()
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_app_grid, parent, false)
            return ViewHolder(v)
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val item = list[position]
            holder.tvName.text = item.appName
            holder.itemView.setOnClickListener { onClick(item, AppLaunchMode.NORMAL) }
            holder.itemView.setOnLongClickListener {
                onClick(item, AppLaunchMode.SPLIT_SCREEN)
                true
            }

            CoroutineScope(Dispatchers.Main).launch {
                val icon = AppRepository.getInstance(context).getAppIcon(item, false)
                holder.ivIcon.setImageBitmap(icon)
            }
        }

        override fun getItemCount(): Int = list.size

        class ViewHolder(v: View) : RecyclerView.ViewHolder(v) {
            val ivIcon: ImageView = v.findViewById(R.id.iv_app_icon)
            val tvName: TextView = v.findViewById(R.id.tv_app_name)
        }
    }
}
