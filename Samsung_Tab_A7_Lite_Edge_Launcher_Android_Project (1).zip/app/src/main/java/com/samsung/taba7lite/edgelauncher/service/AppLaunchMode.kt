package com.samsung.taba7lite.edgelauncher.service

enum class AppLaunchMode {
    NORMAL,
    SPLIT_SCREEN,
    FREEFORM_POPUP
}
