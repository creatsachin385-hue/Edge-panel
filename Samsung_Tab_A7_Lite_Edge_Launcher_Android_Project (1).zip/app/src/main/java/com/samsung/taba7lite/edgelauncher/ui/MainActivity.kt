package com.samsung.taba7lite.edgelauncher.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.samsung.taba7lite.edgelauncher.databinding.ActivityMainBinding
import com.samsung.taba7lite.edgelauncher.service.EdgeOverlayService

/**
 * MainActivity
 * 
 * Clean onboarding flow tailored for Samsung Galaxy Tab A7 Lite (One UI Core):
 * 1. Checks Settings.canDrawOverlays(this)
 * 2. Guides user to disable Samsung "Deep Sleeping Apps" battery optimization
 * 3. Starts and stops EdgeOverlayService
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupListeners()
    }

    override fun onResume() {
        super.onResume()
        updatePermissionStatus()
    }

    private fun setupListeners() {
        binding.btnGrantOverlay.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            } else {
                Toast.makeText(this, "Overlay permission already granted", Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnWhitelistBattery.setOnClickListener {
            val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
            if (!powerManager.isIgnoringBatteryOptimizations(packageName)) {
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = Uri.parse("package:$packageName")
                }
                startActivity(intent)
            } else {
                Toast.makeText(this, "Battery optimization already ignored", Toast.LENGTH_SHORT).show()
            }
        }

        binding.switchService.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                    Toast.makeText(this, "कृपया पहले 'Appear on top' (Overlay) अनुमति दें!", Toast.LENGTH_LONG).show()
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                    startActivity(intent)
                    binding.switchService.isChecked = false
                    return@setOnCheckedChangeListener
                }
                startOverlayService()
            } else {
                stopOverlayService()
            }
        }
    }

    private fun updatePermissionStatus() {
        val hasOverlay = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else {
            true
        }
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        val isBatteryIgnored = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            powerManager.isIgnoringBatteryOptimizations(packageName)
        } else {
            true
        }

        binding.tvOverlayStatus.text = if (hasOverlay) "Granted (अनुमति मिल गई)" else "Required (अनुमति दें)"
        binding.tvBatteryStatus.text = if (isBatteryIgnored) "Whitelisted (सुरक्षित)" else "Optimization active (अनुरोध करें)"

        binding.btnGrantOverlay.isEnabled = !hasOverlay
        binding.btnWhitelistBattery.isEnabled = !isBatteryIgnored
    }

    private fun startOverlayService() {
        try {
            val serviceIntent = Intent(this, EdgeOverlayService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
            Toast.makeText(this, "Edge Sidebar चालू हो गया!", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            android.util.Log.e("MainActivity", "Failed to start overlay service", e)
            Toast.makeText(this, "Error starting service: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun stopOverlayService() {
        try {
            val serviceIntent = Intent(this, EdgeOverlayService::class.java)
            stopService(serviceIntent)
            Toast.makeText(this, "Edge Sidebar बंद हो गया", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            // ignore
        }
    }
    }
}
